# 自由视界 AI · Netlify 部署版

这是自由视界 AI 公司官网的独立静态部署项目，适用于 GitHub 持续部署或 Netlify 手动上传。

## 本地运行

```bash
npm install
npm run dev
```

## 构建

```bash
npm ci
npm run build
```

构建结果位于 `out/`。

## Netlify 设置

- Base directory：留空
- Build command：`npm run build`
- Publish directory：`out`
- Node.js：`22.13.0`

根目录的 `netlify.toml` 已包含上述设置。若使用手动部署，直接上传单独提供的部署压缩包即可。

## 更新样片

样片分类和占位数据位于 `app/company-site.tsx` 的 `sampleCategories`。收到正式视频后，将对应 `src` 替换为视频地址或静态文件路径即可。
